# CANB Dashboard Design Kit

CANB Magenta 브랜드 컬러 기반의 Claude AI 대시보드 디자인 시스템입니다.
이 키트를 사용하면 Claude Code로 일관된 스타일의 대시보드를 빠르게 생성할 수 있습니다.

---

## 패키지 구성

```
canb-dashboard-kit/
├── claude-skill/
│   └── canb-dashboard.md    ← Claude Code 슬래시 커맨드
├── styles/
│   ├── tokens.css           ← 색상·간격·타이포 토큰
│   └── common.css           ← 컴포넌트 스타일 (카드·버튼·배지·테이블)
├── js/
│   ├── utils.js             ← 차트 컬러·포맷 함수
│   └── layout.js            ← 사이드바·테마·브레드크럼
└── DESIGN SYSTEM.MD         ← 디자인 스펙 전체 문서
```

---

## 설치 방법

### 1단계 — Claude 스킬 등록

`claude-skill/canb-dashboard.md` 파일을 아래 경로에 복사합니다.

- **Windows**: `C:\Users\{사용자명}\.claude\commands\`
- **Mac/Linux**: `~/.claude/commands/`

### 2단계 — 베이스 파일 복사

새 프로젝트 폴더에 `styles/`, `js/`, `DESIGN SYSTEM.MD`를 그대로 복사합니다.

```
my-dashboard/
├── styles/
│   ├── tokens.css
│   └── common.css
├── js/
│   ├── utils.js
│   └── layout.js
└── DESIGN SYSTEM.MD
```

### 3단계 — Claude Code에서 사용

Claude Code를 프로젝트 폴더에서 열고:

```
/canb-dashboard
수강 관리 페이지 만들어줘
```

---

## 요구사항

- Claude Code (최신 버전)
- 브라우저 (빌드 불필요 — 바로 열기)

---

## 라이선스

CANB 캠퍼스 내부 사용 전용
